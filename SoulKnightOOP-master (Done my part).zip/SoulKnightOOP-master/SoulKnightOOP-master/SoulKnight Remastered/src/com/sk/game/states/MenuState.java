package com.sk.game.states;

import com.sk.game.GamePanel;
import com.sk.game.entities.Player;
import com.sk.game.graphics.Assets;
import com.sk.game.graphics.Sprite;
import com.sk.game.utils.KeyHandler;
import com.sk.game.utils.MouseHandler;
import com.sk.game.utils.Vector2f;
import com.sk.handler.Handler;
import com.sk.ui.UIManager;
import com.sk.ui.UIObject;
import com.sk.game.states.*;
import com.sk.ui.ClickListener;
import com.sk.ui.UIImageButton;


import com.sk.game.GamePanel;

import java.awt.*;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

public class MenuState extends GameState {

    
	private  UIObject u = null,u1=null;
	private Font font;
    private Player player;
    private UIManager uiManager;
    private GameState[] states;
    private Sprite sprite;
    private Handler handler;
    private MouseHandler mouse;
    private KeyHandler key;
    private Rectangle bounds;
	
    
    public MenuState(GameStateManager gsm) {
        super(gsm);
        font = new Font("font/ZeldaFont.png", 16, 16);
        
        

      
        
        sprite = new Sprite("entity/linkFormatted.png");
        
        uiManager = new UIManager(gsm);
        
        uiManager.input(mouse, key);
        uiManager.addObject( u = new UIImageButton(200, 200, 128, 64, Assets.btn_start, gsm) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if(e.getX()<= 1 || e.getY()<= 1) {
      			  
      		  }else {
      				
      				if(u.bounds.contains((int)e.getX(),(int) e.getY())) {
      					getGsm().addAndPop(0, 1);
      					
      				}
      				else {
      					
      					
      				}
      			}
        	}
        });
        	
    
			

        
        		
        uiManager.addObject(u1 = new UIImageButton(200, 400, 128, 64, Assets.btn_end, gsm) {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		if(e.getX()<= 1 || e.getY()<= 1) {
      			  
      		  }else {
      				
      				if(u1.bounds.contains((int)e.getX(),(int) e.getY())) {
      					
      					gsm.gameStop();
      				}
      				else {
      					
      					
      				}
      			}
        	}
        });
        
    }

    public void update() {
        uiManager.update();
    }

    public void input(MouseHandler mouse, KeyHandler key) {
        uiManager.input(mouse, key);
    }

    public void render(Graphics2D gp2d) {
    	Sprite.drawArray(gp2d, font, "SOUL KNIGHT", new Vector2f(300, 300), 32, 32, 24, 0);
        uiManager.render(gp2d);
    }
}
